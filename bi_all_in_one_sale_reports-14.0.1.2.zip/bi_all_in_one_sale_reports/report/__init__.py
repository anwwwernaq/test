# -*- coding: utf-8 -*-
# Part of BrowseInfo. See LICENSE file for full copyright and licensing details.

from . import user_wise_sales_detail_report_abstract
from . import sale_day_book_report_abstract

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4: